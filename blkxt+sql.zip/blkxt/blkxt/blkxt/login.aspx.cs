﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace blkxt
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string uname = txtUserName.Text;
            string pwd = txtUserPwd.Text;
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
            conn.Open();


            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "select count(*) from [admin] where [账号]=@uname and [密码]=@upwd";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@uname",uname),
                new SqlParameter("@upwd",pwd)
            };

            cmd.Parameters.AddRange(parameters);


            cmd.Connection = conn;

            int count = (int)cmd.ExecuteScalar();
            if (count == 1)
            {
                cmd.CommandText = "select [权限] from [admin] where [账号]='"+uname+"'and [密码]='"+pwd+"'";
                string qx = Convert.ToString(cmd.ExecuteScalar());
                qx = qx.Trim();
                Session["name"] = uname;
                Session["loginTime"] = DateTime.Now.ToString();
                if (qx == "admin" && RadioButton3.Checked) { Response.Redirect("./admin.aspx");  }
                else if (qx == "医生" && RadioButton1.Checked) { Response.Redirect("./doc_info.aspx"); }
                else if (qx == "病人" && RadioButton2.Checked) { Response.Redirect("./pat_info.aspx"); }
                else { Response.Write("<script>alert('权限错误')</script>"); }

            }
            else
            {
                Response.Write("<script>alert('用户名或密码错误')</script>");
            }

            conn.Close();
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("./register.aspx");
        }

        protected void btnVisitor_Click(object sender, EventArgs e)
        {
            Response.Redirect("./PersonSearch.aspx");
        }
    }
}