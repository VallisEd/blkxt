﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;
namespace blkxt
{
    public partial class doc_info : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string num = (string)Session["name"];//（doc_searchpat.aspx输入的ID）;
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
            conn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "Select [医生姓名] from [doc] where [医生工号]=@num";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@num",num),
            };
            cmd.Parameters.AddRange(parameters);
            string dname = Convert.ToString(cmd.ExecuteScalar());
            userName.Text = dname;
            cmd.CommandText = "Select [医生工号] from [doc] where [医生工号]=@num";
            string did = Convert.ToString(cmd.ExecuteScalar());
            id.Text = did;

            cmd.CommandText = "Select [性别] from [doc] where [医生工号]=@num";
            string sex = Convert.ToString(cmd.ExecuteScalar());
            if (sex != "NULL")
            {
                if (sex == "男") { RadioButton1.Checked=true; }

                if (sex == "女") { RadioButton2.Checked = true; }
            }

            cmd.CommandText = "Select [身份证] from [doc] where [医生工号]=@num";
            string idcard = Convert.ToString(cmd.ExecuteScalar());
            if (idcard != "NULL")
            {
                txtAge.Text = idcard;
            }

            cmd.CommandText = "Select [工龄] from [doc] where [医生工号]=@num";
            string Wage = Convert.ToString(cmd.ExecuteScalar());
            if (Wage != "NULL")
            {
                txtMarry.Text = Wage;
            }

            cmd.CommandText = "Select [科室] from [doc] where [医生工号]=@num";
            string keshi = Convert.ToString(cmd.ExecuteScalar());
            if (keshi != "NULL")
            {
                txtKeshi.Text = keshi;
            }

            cmd.CommandText = "Select [等级职称] from [doc] where [医生工号]=@num";
            string zhic = Convert.ToString(cmd.ExecuteScalar());
            if (zhic != "NULL")
            {
                txtZhicheng.Text = zhic;
            }
            cmd.CommandText = "Select [联系电话] from [doc] where [医生工号]=@num";
            string phone = Convert.ToString(cmd.ExecuteScalar());
            if (phone != "NULL")
            {
                txtPhone.Text = phone;
            }

            cmd.CommandText = "Select [住址] from [doc] where [医生工号]=@num";
            string Address = Convert.ToString(cmd.ExecuteScalar());
            if (Address != "NULL")
            {
                txtAddress.Text = Address;
            }

            cmd.CommandText = "Select [个人介绍] from [doc] where [医生工号]=@num";
            string Introduce = Convert.ToString(cmd.ExecuteScalar());
            if (Introduce != "NULL")
            {
                txtIntroduce.Text = Introduce;
            }
            cmd.CommandText = "Select [照片路径] from [doc] where [医生工号]=@num";
            string url= Convert.ToString(cmd.ExecuteScalar());
            if (url != "NULL")
            {
                Image2.ImageUrl = url;
            }
            conn.Close();
        }

        protected void btnSummit_Click(object sender, EventArgs e)
        {
            string name = userName.Text;
            string num = id.Text;
            string sex = RadioButton1.Text;
            string age = txtAge.Text;
            string time = txtMarry.Text;
            string subject = txtKeshi.Text;
            string job = txtZhicheng.Text;
            string tel = txtPhone.Text;
            string address = txtAddress.Text;
            string introduce = txtIntroduce.Text;
            if (RadioButton1.Checked == true)
            {
                sex = RadioButton1.Text;
            }
            else if (RadioButton2.Checked == true)
            {
                sex = RadioButton2.Text;
            }

            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
            conn.Open();

            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "update [doc] set[性别]=@sex,[科室]=@subject,[等级职称]=@job,[联系电话]=@tel,[住址]=@address,[工龄]=@time,[个人介绍]=@introduce where[医生工号]=@num";
            SqlParameter[] parameters = new SqlParameter[]
           {
                new SqlParameter("@num",num),
           };
            cmd.Parameters.AddRange(parameters);
            SqlParameter psex = new SqlParameter();
            psex.Value = sex;
            psex.DbType = System.Data.DbType.String;
            psex.ParameterName = "@sex";
            cmd.Parameters.Add(psex);
            SqlParameter psubject = new SqlParameter();
            psubject.Value = subject;
            psubject.DbType = System.Data.DbType.String;
            psubject.ParameterName = "@subject";
            cmd.Parameters.Add(psubject);
            SqlParameter pjob = new SqlParameter();
            pjob.Value = job;
            pjob.DbType = System.Data.DbType.String;
            pjob.ParameterName = "@job";
            cmd.Parameters.Add(pjob);
            SqlParameter ptel = new SqlParameter();
            ptel.Value = tel;
            ptel.DbType = System.Data.DbType.String;
            ptel.ParameterName = "@tel";
            cmd.Parameters.Add(ptel);
            SqlParameter paddress = new SqlParameter();
            paddress.Value = address;
            paddress.DbType = System.Data.DbType.String;
            paddress.ParameterName = "@address";
            cmd.Parameters.Add(paddress);
            SqlParameter ptime = new SqlParameter();
            ptime.Value = time;
            ptime.DbType = System.Data.DbType.String;
            ptime.ParameterName = "@time";
            cmd.Parameters.Add(ptime);
            SqlParameter pintroduce = new SqlParameter();
            pintroduce.Value = introduce;
            pintroduce.DbType = System.Data.DbType.String;
            pintroduce.ParameterName = "@introduce";
            cmd.Parameters.Add(pintroduce);

            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
            conn.Close();
            Response.Write("<script>alert('修改信息成功')</script>");
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            string path = Server.MapPath("~/image");
            bool hasFile = FileUpload1.HasFile;
            if (!hasFile) { return; }
            long size = FileUpload1.FileContent.Length;
            int srdSize = 1024 * 1024;
            if (size > srdSize)
            {
                txtSrdsize.Text = "文件过大";
                return;
            }
            string fileName = FileUpload1.FileName;
            string extname = fileName.Substring(fileName.LastIndexOf('.')).ToLower();
            if (!(extname == ".jpg" || extname == ".png" || extname == ".jpeg" || extname == "bmp"))
            {
                txtSrdsize.Text = "文件类型不正确";
                return;
            }
            string newName = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss-fff") + extname;
            string savedNamePath = Path.Combine(path, newName);
            FileUpload1.SaveAs(savedNamePath);
            txtSrdsize.Text = "上传成功";
            Image2.ImageUrl = "~/image/" + newName;



            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
            conn.Open();
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "update [doc] set [照片路径]=@url where [医生工号]=" + (string)Session["name"]; ;
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@url",Image2.ImageUrl),
            };

            cmd.Parameters.AddRange(parameters);
            cmd.Connection = conn;
            string url = Convert.ToString(cmd.ExecuteScalar());
            conn.Close();
        }
    }
}