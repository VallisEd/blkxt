﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace blkxt
{
    public partial class admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public string str = "";

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string id = txtID.Text;
            string name = txtName.Text;
            string keshi = txtKeshi.Text;
            string zhicheng = txtZhicheng.Text;
            int flag = 0;
            int c=0;
            int count = 0;
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
            conn.Open();
            SqlCommand cmd = new SqlCommand();


            if (id.Length != 0)
            {
                cmd.CommandText = "select max(id) from [doc] where [医生工号]=" + id;
                flag = 1;
            }
            else if (name.Length != 0)
            {
                cmd.CommandText = "select max(id) from [doc] where [医生姓名]='" + name + "'";
                flag = 2;
            }
            else if (keshi.Length != 0)
            {
                cmd.CommandText = "select max(id) from [doc] where [科室]='" + keshi + "'";
                flag = 3;
            }
            else if (zhicheng.Length != 0)
            {
                cmd.CommandText = "select max(id) from [doc] where [等级职称]='" + zhicheng + "'";
                flag = 4;
            }
            else
            {
                cmd.CommandText = "select max(id) from [doc] ";
                flag = 0;
            }
            cmd.Connection = conn;
            count = (int)cmd.ExecuteScalar();
            
            for (int i = 0; i <= count; i++)
            {
                if (flag == 1) { cmd.CommandText = "select count(*) from [doc] where [医生工号]=" + id + "and  id=" + i; }
                else if (flag == 2) { cmd.CommandText = "select count(*) from [doc] where [医生姓名]='" + name + "' and  id=" + i; }
                else if (flag == 3) { cmd.CommandText = "select count(*) from [doc] where [科室]='" + keshi + "' and  id=" + i; }
                else if (flag == 4) { cmd.CommandText = "select count(*) from [doc] where [等级职称]='" + zhicheng + "' and  id=" + i; }
                else if (flag == 0) { cmd.CommandText = "select count(*) from [doc] where  id=" + i; }
                int count2 = (int)cmd.ExecuteScalar();

                if (count2 != 0)
                {
                    c = c + 1;
                    str += "<tr>";
                    cmd.CommandText = "select [医生工号] from [doc] where id =" + i;
                    string date = Convert.ToString(cmd.ExecuteScalar());
                    cmd.CommandText = "select [医生姓名] from [doc] where id =" + i;
                    string num = Convert.ToString(cmd.ExecuteScalar());
                    cmd.CommandText = "select [性别] from [doc] where id =" + i;
                    string username = Convert.ToString(cmd.ExecuteScalar());
                    cmd.CommandText = "select [工龄] from [doc] where id =" + i;
                    string age = Convert.ToString(cmd.ExecuteScalar());
                    cmd.CommandText = "select [科室] from [doc] where id =" + i;
                    string disease = Convert.ToString(cmd.ExecuteScalar());
                    cmd.CommandText = "select [等级职称] from [doc] where id =" + i;
                    string yaowu = Convert.ToString(cmd.ExecuteScalar());
                    cmd.CommandText = "select [联系电话] from [doc] where id =" + i;
                    string chuanghao = Convert.ToString(cmd.ExecuteScalar());
                    cmd.CommandText = "select [住址] from [doc] where id =" + i;
                    string doctor = Convert.ToString(cmd.ExecuteScalar());
                    cmd.CommandText = "select [身份证] from [doc] where id =" + i;
                    string phone = Convert.ToString(cmd.ExecuteScalar());
                    cmd.CommandText = "select [个人介绍] from [doc] where id =" + i;
                    string zhuyisx = Convert.ToString(cmd.ExecuteScalar());
                    str += "<td>" + date + "</td>" + "<td>" + num + "</td>" + "<td>" + username + "</td>" + "<td>" + age + "</td>" +
                        "<td>" + disease + "</td>" + "<td>" + yaowu + "</td>" + "<td>" + chuanghao + "</td>" + "<td>" + doctor + "</td>"
                        + "<td>" + phone + "</td>" + "<td>" + zhuyisx + "</td>";
                    str += "</tr>";
                }

            }
            Label1.Text = "   查询条数："+c +"条";
            conn.Close();
        }
    }
}