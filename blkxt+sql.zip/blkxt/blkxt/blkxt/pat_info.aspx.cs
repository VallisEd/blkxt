﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;

namespace blkxt
{
    public partial class pat_info : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           string num = (string)Session["name"];//（登录输入的ID）;
           txtIDcard.Text = num;
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
            conn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "Select [病人姓名] from [pat] where [身份证号码]=@num";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@num",num),
            };
            cmd.Parameters.AddRange(parameters);
            string dname = Convert.ToString(cmd.ExecuteScalar());
            userName.Text = dname;

            cmd.CommandText = "Select [性别] from [pat] where [身份证号码]=@num";
            string sex = Convert.ToString(cmd.ExecuteScalar());
            if (sex != "NULL")
            {
                if (sex == "男") { RadioButton1.Checked = true; }

                if (sex == "女") { RadioButton2.Checked = true; }
            }

            cmd.CommandText = "Select [年龄] from [pat] where [身份证号码]=@num";
            string idcard = Convert.ToString(cmd.ExecuteScalar());
            if (idcard != "NULL")
            {
                txtAge.Text = idcard;
            }

            cmd.CommandText = "Select [婚姻状况] from [pat] where [身份证号码]=@num";
            string Marry = Convert.ToString(cmd.ExecuteScalar());
            if (Marry != "NULL")
            {
                txtMarry.Text = Marry;
            }



            cmd.CommandText = "Select [联系电话] from [pat] where [身份证号码]=@num";
            string phone = Convert.ToString(cmd.ExecuteScalar());
            if (phone != "NULL")
            {
                txtPhone.Text = phone;
            }

            cmd.CommandText = "Select [家庭住址] from [pat] where [身份证号码]=@num";
            string Address = Convert.ToString(cmd.ExecuteScalar());
            if (Address != "NULL")
            {
                txtAddress.Text = Address;
            }


            cmd.CommandText = "Select [照片] from [pat] where [身份证号码]=@num";
            string url = Convert.ToString(cmd.ExecuteScalar());
            if (url != "NULL")
            {
                Image2.ImageUrl = url;
            }
            conn.Close();
        }

        protected void btnSummit_Click(object sender, EventArgs e)
        {
            string name = userName.Text;
            string address = txtAddress.Text;
            string uname = userName.Text;
            string idnum = txtIDcard.Text;
            string phonenum = txtPhone.Text;
            string marry = txtMarry.Text;
            string age = txtAge.Text;
            string sex;
            if (RadioButton1.Checked == true)
            {
                sex = RadioButton1.Text;
            }
            else
            {
                sex = RadioButton2.Text;
            }
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
            conn.Open();

            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Update  [pat]  set [性别]=@sex ,[年龄]=@age,[婚姻状况]=@marry,[家庭住址]=@address,[联系电话]=@phone where[病人姓名]=@name";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@name",name),
                new SqlParameter("@phone",phonenum)
            };
            cmd.Parameters.AddRange(parameters);
           /* SqlParameter pidnum = new SqlParameter();
            pidnum.Value = idnum;
            pidnum.DbType = System.Data.DbType.String;
            pidnum.ParameterName = "@idnum";
            cmd.Parameters.Add(pidnum);*/
            SqlParameter psex = new SqlParameter();
            psex.Value = sex;
            psex.DbType = System.Data.DbType.String;
            psex.ParameterName = "@sex";
            cmd.Parameters.Add(psex);
            SqlParameter page = new SqlParameter();
            page.Value = age;
            page.DbType = System.Data.DbType.String;
            page.ParameterName = "@age";
            cmd.Parameters.Add(page);
            SqlParameter pmarry = new SqlParameter();
            pmarry.Value = marry;
            pmarry.DbType = System.Data.DbType.String;
            pmarry.ParameterName = "@marry";
            cmd.Parameters.Add(pmarry);
            SqlParameter paddress = new SqlParameter();
            paddress.Value = address;
            paddress.DbType = System.Data.DbType.String;
            paddress.ParameterName = "@address";
            cmd.Parameters.Add(paddress);

            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
            conn.Close();
            Response.Write("<script>alert('修改信息成功')</script>");
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            string path = Server.MapPath("~/image");
            bool hasFile = FileUpload1.HasFile;
            if (!hasFile) { return; }
            long size = FileUpload1.FileContent.Length;
            int srdSize = 1024 * 1024;
            if (size > srdSize)
            {
                txtSrdsize.Text = "文件过大";
                return;
            }
            string fileName = FileUpload1.FileName;
            string extname = fileName.Substring(fileName.LastIndexOf('.')).ToLower();
            if (!(extname == ".jpg" || extname == ".png" || extname == ".jpeg" || extname == "bmp"))
            {
                txtSrdsize.Text = "文件类型不正确";
                return;
            }
            string newName = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss-fff") + extname;
            string savedNamePath = Path.Combine(path, newName);
            FileUpload1.SaveAs(savedNamePath);
            txtSrdsize.Text = "上传成功";
            Image2.ImageUrl = "~/image/" + newName;



            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
            conn.Open();
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "update [pat] set [照片]=@url where [身份证号码]=" + (string)Session["name"]; ;
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@url",Image2.ImageUrl),
            };

            cmd.Parameters.AddRange(parameters);
            cmd.Connection = conn;
            string url = Convert.ToString(cmd.ExecuteScalar());
            conn.Close();
        }
    }
}