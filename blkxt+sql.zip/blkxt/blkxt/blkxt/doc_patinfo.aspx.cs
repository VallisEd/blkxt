﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace blkxt
{
    public partial class doc_patinfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
                string num = (string)Session["ID"];
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
                conn.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "Select [病人姓名] from [pat] where [身份证号码]=@num";
                SqlParameter[] parameters = new SqlParameter[]
                {
                new SqlParameter("@num",num),
                };
                cmd.Parameters.AddRange(parameters);
                string dname = Convert.ToString(cmd.ExecuteScalar());
                labName.Text = dname;
                cmd.CommandText = "Select [年龄] from [pat] where [身份证号码]=@num";
                string dage = Convert.ToString(cmd.ExecuteScalar());
                labAge.Text = dage;
                cmd.CommandText = "Select [性别] from [pat] where [身份证号码]=@num";
                string dsex = Convert.ToString(cmd.ExecuteScalar());
                labSex.Text = dsex;
                cmd.CommandText = "Select [联系电话] from [pat] where [身份证号码]=@num";
                string dphone = Convert.ToString(cmd.ExecuteScalar());
                labPhone.Text = dphone;
                cmd.CommandText = "Select [身份证号码] from [pat] where [身份证号码]=@num";
                string dnum = Convert.ToString(cmd.ExecuteScalar());
                labIDcard.Text = dnum;
                cmd.CommandText = "Select [照片] from [pat] where [身份证号码]=@num";
                string url = Convert.ToString(cmd.ExecuteScalar());
                if (url != "NULL")
                {
                    Image1.ImageUrl = url;
                }
                conn.Close();
            
        }

        protected void btnSummit_Click(object sender, EventArgs e)
        {

                string name = labName.Text;
                string phonenum = labPhone.Text;
                string age = labAge.Text;
                // string sex=labSex.Text;
                string disease = txtDisease.Text;
                string medicine = txtMachine.Text;
                string remark = txtRemark.Text;
                string advice = txtAdvice.Text;
                string outp = txtOutpatient.Text;
                string bed = txtBed.Text;
                string idcard = (string)Session["ID"];
                string docid = (string)Session["name"];
               /* SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
                conn.Open();

                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "update [bingli] set [病症]=@disease,[使用药物]=@medicine,[备注]=@remark,[注意事项]=@advice,[门诊号]=@outp,[床号]=@bed , [姓名]=@name";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@name",name),
                };
                cmd.Parameters.AddRange(parameters);
                SqlParameter pdisease = new SqlParameter();
                pdisease.Value = disease;
                pdisease.DbType = System.Data.DbType.String;
                pdisease.ParameterName = "@disease";
                cmd.Parameters.Add(pdisease);
                SqlParameter pmedicine = new SqlParameter();
                pmedicine.Value = medicine;
                pmedicine.DbType = System.Data.DbType.String;
                pmedicine.ParameterName = "@medicine";
                cmd.Parameters.Add(pmedicine);
                SqlParameter premark = new SqlParameter();
                premark.Value = remark;
                premark.DbType = System.Data.DbType.String;
                premark.ParameterName = "@remark";
                cmd.Parameters.Add(premark);
                SqlParameter padvice = new SqlParameter();
                padvice.Value = advice;
                padvice.DbType = System.Data.DbType.String;
                padvice.ParameterName = "@advice";
                cmd.Parameters.Add(padvice);
                SqlParameter poutp = new SqlParameter();
                poutp.Value = outp;
                poutp.DbType = System.Data.DbType.String;
                poutp.ParameterName = "@outp";
                cmd.Parameters.Add(poutp);
                SqlParameter pbed = new SqlParameter();
                pbed.Value = bed;
                pbed.DbType = System.Data.DbType.String;
                pbed.ParameterName = "@bed";
                cmd.Parameters.Add(pbed);
                SqlParameter namepat = new SqlParameter();
                namepat.Value = bed;
                namepat.DbType = System.Data.DbType.String;
                namepat.ParameterName = "@name";
                cmd.Parameters.Add(namepat);


                SqlParameter namepat = new SqlParameter();
                namepat.Value = bed;
                namepat.DbType = System.Data.DbType.String;
                namepat.ParameterName = "@name";
                cmd.Parameters.Add(namepat);
                cmd.Connection = conn;
                cmd.ExecuteNonQuery();
                conn.Close();*/

                docid = docid.Trim();
                string date = DateTime.Now.ToShortDateString().ToString();
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = "Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                
                cmd.CommandText = "select [医生姓名] from [doc] where 医生工号 ='" + docid + "'";
                cmd.Connection = conn;
                string docname = Convert.ToString(cmd.ExecuteScalar());
                cmd.CommandText =
"insert into [bingli]([日期],[姓名],[年龄],[身份证号码],[主治医生],[病症],[门诊号],[床号],[使用药物],[备注],[注意事项],[医生工号]) values(@date,@name,@age,@idcard,@docname,@dis,@mzh,@bed,@med,@bz,@zysx,@docid)";
                SqlParameter[] parameters = new SqlParameter[]
            {   
               new SqlParameter("@date",date),
                new SqlParameter("@name",name),
                new SqlParameter("@age",age),
                new SqlParameter("@idcard",idcard),
                new SqlParameter("@docname",docname),
                new SqlParameter("@dis",disease),
                 new SqlParameter("@mzh",outp),
                 new SqlParameter("@bed",bed),
                new SqlParameter("@med",medicine),
                new SqlParameter("@bz",remark),
                new SqlParameter("@zysx",advice),
               new SqlParameter("@docid",docid)
            };

                cmd.Parameters.AddRange(parameters);
               
                int count = cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("<script>alert('修改信息成功')</script>");
        }
    }
}