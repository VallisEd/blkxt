﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace blkxt
{
    public partial class register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            string idcard = txtIDcard.Text;
            string pwd;
            if (idcard.Length != 18) { Response.Write("<script>alert('身份证号长度不对')</script>"); }
             pwd = txtPwd1.Text; 
            string name = txtName.Text;
            string phone = txtPhone.Text;
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
            conn.Open();
            int flag = 2;
            string id = txtWorkerID.Text;
            SqlCommand cmd = new SqlCommand();   
            cmd.Connection = conn;

            if (id.Length!=0)
            {
                cmd.CommandText = "select count(*) from [id] where [id]='" + id+"'";
                int count1 = (int)cmd.ExecuteScalar();

                if (count1 == 1)
                {
                    cmd.CommandText = "select count(*) from [admin] where [账号]='" + id+"'";
                    flag = (int)cmd.ExecuteScalar();
                }

                else if(count1==0) { Response.Write("<script>alert('工号错误')</script>"); }
                if (flag == 1) { Response.Write("<script>alert('账号已存在')</script>"); }

                else if (flag == 0)
                {
                    cmd.CommandText = "insert into [doc]([医生姓名],[身份证],[联系电话],[医生工号]) Values(@uname, @uidcard,@uphone,@uid)";

                    SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@uname",name),
                new SqlParameter("@uidcard",idcard),
                new SqlParameter("@uphone",phone),
                 new SqlParameter("@uid",id),

            };

                    cmd.Parameters.AddRange(parameters);
                    int count = cmd.ExecuteNonQuery();
                    cmd.CommandText = "insert into [admin]([账号],[密码],[权限]) Values(@uidc, @upwd,@qx)";

                    SqlParameter[] parameter = new SqlParameter[]
            {
                new SqlParameter("@uidc",id),
                new SqlParameter("@upwd",pwd),
                new SqlParameter("@qx","医生"),

            };
                    cmd.Parameters.AddRange(parameter);
                    int count2 = cmd.ExecuteNonQuery();
                    if (count2 == 1&& count==1)
                    {
                        Response.Redirect("./doc_info.aspx");

                    }
                }
            }
                else
                {
                 cmd.CommandText = "select count(*) from [admin] where [账号]='" + idcard+"'";
                int count1 = (int)cmd.ExecuteScalar();

                if (count1 == 1)
                {
                    Response.Write("<script>alert('账号已存在')</script>");                    
                }
                else{
                    cmd.CommandText = "insert into [pat]([病人姓名],[身份证号码],[联系电话]) Values(@pname, @pidcard,@pphone)";  
                    SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@pname",name),
                new SqlParameter("@pphone",phone),
                 new SqlParameter("@pidcard",idcard)

            };

                    cmd.Parameters.AddRange(parameters);
                    int count = cmd.ExecuteNonQuery();
                    cmd.CommandText = "insert into [admin]([账号],[密码],[权限]) Values(@uidc, @upwd,@qx)";

                    SqlParameter[] parameter = new SqlParameter[]
            {
                new SqlParameter("@uidc",idcard),
                new SqlParameter("@upwd",pwd),
                new SqlParameter("@qx","病人"),

            };
                    cmd.Parameters.AddRange(parameter);
                    int count2 = cmd.ExecuteNonQuery();
                    if (count == 1&&count2==1)
                    {
                        Response.Redirect("./pat_info.aspx");
                    }
                }              
                }
                conn.Close();
            }
        }
    }
