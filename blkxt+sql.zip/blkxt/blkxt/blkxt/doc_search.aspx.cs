﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace blkxt
{
    public partial class doc_search : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            

        }
         public string str = "";
        protected void btnSearch_Click(object sender, EventArgs e)
        {
                string id = (string)Session["name"] ;
                int c = 0;
                int count=0;
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "select max(id) from [bingli] where [医生工号]=" + id;
                cmd.Connection = conn;
                count = (int)cmd.ExecuteScalar();
            
            for (int i = 0;i<=count ; i++) {
                cmd.CommandText = "select count(*) from [bingli] where [医生工号]="+id+"and  id=" + i;
                int count2=(int)cmd.ExecuteScalar();

                 if (count2 != 0)
                 {
                     c = c + 1;
                      str += "<tr>";
                     cmd.CommandText = "select [日期] from [bingli] where id =" + i;
                     string date = Convert.ToString(cmd.ExecuteScalar());
                     cmd.CommandText = "select [门诊号] from [bingli] where id =" + i;
                     string num = Convert.ToString(cmd.ExecuteScalar());
                     cmd.CommandText = "select [姓名] from [bingli] where id =" + i;
                     string username = Convert.ToString(cmd.ExecuteScalar());
                     cmd.CommandText = "select [年龄] from [bingli] where id =" + i;
                     string age = Convert.ToString(cmd.ExecuteScalar());
                     cmd.CommandText = "select [病症] from [bingli] where id =" + i;
                     string disease = Convert.ToString(cmd.ExecuteScalar());
                     cmd.CommandText = "select [使用药物] from [bingli] where id =" + i;
                     string yaowu = Convert.ToString(cmd.ExecuteScalar());
                     cmd.CommandText = "select [床号] from [bingli] where id =" + i;
                     string chuanghao = Convert.ToString(cmd.ExecuteScalar());
                     cmd.CommandText = "select [主治医生] from [bingli] where id =" + i;
                     string doctor = Convert.ToString(cmd.ExecuteScalar());
                     cmd.CommandText = "select [备注] from [bingli] where id =" + i;
                     string phone = Convert.ToString(cmd.ExecuteScalar());
                     cmd.CommandText = "select [注意事项] from [bingli] where id =" + i;
                     string zhuyisx = Convert.ToString(cmd.ExecuteScalar());
                     str += "<td>" + date + "</td>" + "<td>" + num + "</td>" + "<td>" + username + "</td>" + "<td>" + age  + "</td>" +
                         "<td>" + disease + "</td>" + "<td>" + yaowu + "</td>" + "<td>" + chuanghao + "</td>" + "<td>" + doctor + "</td>"
                         + "<td>" + phone + "</td>" + "<td>" + zhuyisx + "</td>";
                     str += "</tr>";
                 }
            }
            Label1.Text = "   查询条数：" + c + "条";
            conn.Close();
            }
        }
    }
