﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace blkxt
{
    public partial class pat_advice : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSummit_Click(object sender, EventArgs e)
        {
            string subject = txtDisease.Text;
            string doctor = txtDoctor.Text;
            string advices = advice.Text;
            string datetime = DateTime.Now.ToString();
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
            conn.Open();


            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "insert into [advice]([日期],[科室],[主治医生],[意见内容]) Values (@date,@subject,@doctor,@advice)";
            SqlParameter date = new SqlParameter();
            date.Value = datetime;
            date.DbType = System.Data.DbType.String;
            date.ParameterName = "@date";
            cmd.Parameters.Add(date);
            SqlParameter psubject = new SqlParameter();
            psubject.Value = subject;
            psubject.DbType = System.Data.DbType.String;
            psubject.ParameterName = "@subject";
            cmd.Parameters.Add(psubject);
            SqlParameter pdoctor = new SqlParameter();
            pdoctor.Value = doctor;
            pdoctor.DbType = System.Data.DbType.String;
            pdoctor.ParameterName = "@doctor";
            cmd.Parameters.Add(pdoctor);
            SqlParameter padvice = new SqlParameter();
            padvice.Value = advices;
            padvice.DbType = System.Data.DbType.String;
            padvice.ParameterName = "@advice";
            cmd.Parameters.Add(padvice);

            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
            conn.Close();
            Response.Write("<script>alert('提交建议成功')</script>");
        }
    }
}