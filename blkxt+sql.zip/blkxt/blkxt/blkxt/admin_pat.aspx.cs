﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace blkxt
{
    public partial class admin_pat : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public string str = "";
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string id = txtIDcard.Text;
            string name = txtName.Text;
            int flag = 0;

            int count = 0;
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
            conn.Open();
            SqlCommand cmd = new SqlCommand();


            if (id.Length != 0)
            {
                cmd.CommandText = "select max(id) from [pat] where [身份证号码]=" + id;
                flag = 1;
            }
            else if (name.Length != 0)
            {
                cmd.CommandText = "select max(id) from [pat] where [病人姓名]='" + name + "'";
                flag = 2;
            }
            else
            {
                cmd.CommandText = "select max(id) from [pat] ";
                flag = 0;
            }
            cmd.Connection = conn;
            count = (int)cmd.ExecuteScalar();

            for (int i = 0; i <= count; i++)
            {
                if (flag == 1) { cmd.CommandText = "select count(*) from [pat] where [身份证号码]=" + id + "and  id=" + i; }
                else if (flag == 2) { cmd.CommandText = "select count(*) from [pat] where [病人姓名]='" + name + "' and  id=" + i; }

                else if (flag == 0) { cmd.CommandText = "select count(*) from [pat] where  id=" + i; }
                int count2 = (int)cmd.ExecuteScalar();

                if (count2 != 0)
                {
                    str += "<tr>";
                    cmd.CommandText = "select [身份证号码] from [pat] where id =" + i;
                    string date = Convert.ToString(cmd.ExecuteScalar());
                    cmd.CommandText = "select [病人姓名] from [pat] where id =" + i;
                    string num = Convert.ToString(cmd.ExecuteScalar());
                    cmd.CommandText = "select [性别] from [pat] where id =" + i;
                    string username = Convert.ToString(cmd.ExecuteScalar());
                    cmd.CommandText = "select [年龄] from [pat] where id =" + i;
                    string age = Convert.ToString(cmd.ExecuteScalar());
                    cmd.CommandText = "select [婚姻状况] from [pat] where id =" + i;
                    string disease = Convert.ToString(cmd.ExecuteScalar());
                    cmd.CommandText = "select [联系电话] from [pat] where id =" + i;
                    string yaowu = Convert.ToString(cmd.ExecuteScalar());
                    cmd.CommandText = "select [家庭住址] from [pat] where id =" + i;
                    string chuanghao = Convert.ToString(cmd.ExecuteScalar());
 
                   
                    str += "<td>" + date + "</td>" + "<td>" + num + "</td>" + "<td>" + username + "</td>" + "<td>" + age + "</td>" +
                        "<td>" + disease + "</td>" + "<td>" + yaowu + "</td>" + "<td>" + chuanghao + "</td>" ;
                    str += "</tr>";
                }

            }
            conn.Close();
        }
    }
}