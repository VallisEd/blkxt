﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace blkxt
{
    public partial class doc_searchpat : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSummit_Click(object sender, EventArgs e)
        {
            if (txtpatID.Text != "") {
            Session["ID"] = txtpatID.Text;
            
            Response.Redirect("./doc_patinfo.aspx"); 
            }
            else
            {
                Response.Write("<script>alert('身份证为空')</script>");
            }
        }
    }
}