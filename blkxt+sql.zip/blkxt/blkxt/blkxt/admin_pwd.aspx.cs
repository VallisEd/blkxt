﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace blkxt
{
    public partial class admin_pwd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void btnSummit_Click(object sender, EventArgs e)
        {
 string id = txtID.Text;
            string pwd = txtOldpwd.Text;
            string newpwd = txtNewpwd.Text;
            string newpwd2 = txtNewpwd2.Text;
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=.;Initial Catalog=blkxt;Integrated Security=true;";
            conn.Open();
            if (newpwd != newpwd2)
            {
                Response.Write("<script>alert('两次密码不一致')</script>");
            }
            else if (newpwd == newpwd2)
            {
                Response.Write("<script>alert('修改密码成功')</script>");
            }

            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Update admin Set [密码]=@newpwd where [账号]=@id";
            SqlParameter pid = new SqlParameter();
            pid.Value = id;
            pid.DbType = System.Data.DbType.String;
            pid.ParameterName = "@id";
            cmd.Parameters.Add(pid);
            SqlParameter pnewpwd = new SqlParameter();
            pnewpwd.Value = newpwd;
            pnewpwd.DbType = System.Data.DbType.String;
            pnewpwd.ParameterName = "@newpwd";
            cmd.Parameters.Add(pnewpwd);
            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
            conn.Close();
        }
    }
}